<?php
require "validasi3.php"
  ?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Document</title>
</head>
<style>
  body {
    font-family: "Franklin Gothic Medium", "Arial Narrow", Arial, sans-serif;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;

    /* background: url("https://images.pexels.com/photos/457878/pexels-photo-457878.jpeg") no-repeat center center/cover; */
    background: url("https://images.pexels.com/photos/1450353/pexels-photo-1450353.jpeg") no-repeat center center/cover;
  }

  .container_form {
    display: flex;
    justify-content: space-evenly;
    width: 100vw;
  }

  h2 {
    padding-block: 20px;
    color: rgba(7, 7, 7, 0.8);
    transition: 300ms ease;
  }

  h2:hover {
    color: rgba(1, 72, 252, 1);
  }

  input:-webkit-autofill {
    -webkit-box-shadow: 0 0 0 1000px transparent inset !important;
    background: transparent !important;
    transition: background-color 5000s ease-in-out 0s;
  }



  img {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100dvh;
    object-fit: cover;
    z-index: -1;
  }

  .grup {
    position: relative;
  }

  input {
    background: transparent;
    display: block;
    margin-block: 20px;
    width: 300px;
    border: none;
    border-bottom: 1px solid rgba(17, 17, 17, 0.7);
    outline: none;
    transition: 0.3s ease-in-out;
  }

  label {
    color: rgba(15, 15, 15, 0.7);
    position: absolute;
    left: 5px;
    top: -5px;
    transition: 0.3s ease-in-out;
    letter-spacing: .5px;
  }

  input:focus~label {
    top: -20px;
    color: rgba(1, 72, 252, 1);

  }

  input:focus {
    border-bottom-color: rgba(1, 72, 252, 1);
  }

  input:focus+label,
  input:not(:placeholder-shown)+label {
    top: -20px;
  }

  span{
    z-index: 1000;
  }

  form,
  .output {
    border: 1px solid rgba(255, 255, 255, 0.4);
    border-radius: 20px;
    padding: 20px 30px;
    text-align: center;
    background: rgba(255, 255, 255, 0.01);
    backdrop-filter: blur(5px);
    height: max-content;
  }

  .output{
    width: 300px !important ;
  }


  button {
    letter-spacing: 1px;
    font-weight: 700;
    font-size: 1.1rem;
    cursor: pointer;
    width: 100%;
    border: none;
    border-radius: 10px;
    height: 40px;
    background-color: rgba(24, 86, 243, 1);
    color: white;
  }

</style>

<body>
  <div class="container_form">
    <form action="" method="POST">
      <h2>login</h2>
      <div class="grup">
        <input type="text" id="nama" placeholder=" " name="nama" value="<?php echo $nama ?>" />
        <label for="nama">nama</label>
        <span style="color:red;"><?php echo $namaErr ?></span>
      </div>

      <br />

      <div class="grup">
        <input type="email" id="email" placeholder=" " name="email" value="<?php echo $email ?>" />
        <label for="email">email</label>
        <span style="color:red;"><?php echo $emailErr ?></span>

      </div>

      <br />
      <div class="grup">
        <input type="text" id="alamat" placeholder=" " name="alamat" value="<?php echo $alamat ?>" />
        <label for="alamat">alamat</label>
        <span style="color:red;"><?php echo $alamatErr ?></span>

      </div>

      <br />

      <div class="grup">
        <input type="password" id="password" placeholder=" " name="password" value="<?php echo $password ?>" />
        <label for="password">password</label>
        <span style="color:red;"><?php echo $passwordErr ?></span>

      </div>

      <br />
      <div class="grup">
        <input type="password" id="kon_" placeholder=" " name="kon_" value="<?php echo $kon_ ?>" />
        <label for="kon_">konfirmasi password</label>
        <span style="color:red;"><?php echo $kon_err ?></span>

      </div>


      <br />
      <button>submit</button>
    </form>
    <div class="output">
      <h2>output</h2>
      <?php if (isset($_COOKIE["nama"])):  ?>
      <p><b>Nama:</b> <?= $_COOKIE['nama'] ?></p>
      <p><b>Email:</b> <?= $_COOKIE['email'] ?></p>
      <p><b>Alamat:</b> <?= $_COOKIE['alamat'] ?></p>
      <p><b>Password:</b> <?= $_COOKIE['password'] ?></p>
      <?php else: ?>
          <p>Belum ada data tersimpan.</p>
      <?php endif; ?>
    </div>
  </div>
</body>

</html>